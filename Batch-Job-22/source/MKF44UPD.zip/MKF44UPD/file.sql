use sample1;
create table demo
(id INT ,
username VARCHAR(100),
password varchar(100));

insert into demo values (101,'udajhvd','jasd');
insert into demo values (103,'skjx','jasd'); 